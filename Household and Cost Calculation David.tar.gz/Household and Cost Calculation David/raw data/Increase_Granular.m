clc,format,clear
data=csvread('Profile Matching2.csv')
new_data=zeros(100,4);
for i=1:25
   new_data(4*i-3,:)=data(i,:); 
   new_data(4*i-2,:)=data(i,:); 
   new_data(4*i-1,:)=data(i,:); 
   new_data(4*i,:)=data(i,:); 
    
end

csvwrite(Profile_15mins,new_data)